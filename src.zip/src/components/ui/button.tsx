import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        // Gamme terre cuite : terracotta <-> brun profond au survol.
        default: "bg-primary text-primary-foreground hover:bg-accent-strong",
        destructive: "bg-destructive text-destructive-foreground hover:bg-deep",
        outline:
          "border border-input bg-background hover:border-accent-strong hover:text-accent-strong",
        secondary: "bg-secondary text-secondary-foreground hover:bg-accent hover:text-accent-strong",
        ghost: "hover:bg-accent hover:text-accent-strong",
        link: "text-accent-strong underline-offset-4 hover:underline",
        accent: "bg-accent-strong text-accent-strong-foreground hover:bg-deep",
        accentOutline:
          "border border-accent-strong text-accent-strong bg-transparent hover:bg-accent-strong hover:text-accent-strong-foreground",
        subtle: "bg-accent text-accent-foreground hover:bg-accent-strong hover:text-accent-strong-foreground",
        online: "text-green-600 hover:bg-green-50 hover:text-green-700",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-11 rounded-md px-8 text-[15px]",
        xl: "h-12 rounded-md px-10 text-base",
        icon: "h-9 w-9",
      },

    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
